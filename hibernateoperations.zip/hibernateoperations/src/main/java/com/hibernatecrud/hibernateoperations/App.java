package com.hibernatecrud.hibernateoperations;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
      Book book = new Book();
      book.setBookId(101);
      book.setBookName("Think Like A Monk");
      book.setBookAuthor("Jay Shetty");
      book.setBookPrice(120.80);
     // Session session
      //save(book);
    }
}
